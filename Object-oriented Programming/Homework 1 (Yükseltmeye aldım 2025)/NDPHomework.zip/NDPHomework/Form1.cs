using NDPHomework.Models;

namespace NDPHomework
{
	public partial class Form1 : Form
	{
		// Yiyecek s�n�f�ndan s isimli nesne
		Yiyecek s;

		// Menu s�n�f�ndan m isimli nesne
		Menu m;
		public Form1()
		{
			InitializeComponent();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			// m nesnesini burada �rneklendiriyoruz
			m = new Menu();
			listBox1.Font = new Font("Consolas", 10, FontStyle.Regular);

			// ComboBox�a veri t�rlerimizi ekliyoruz
			comboBox1.Items.Add("Meyve");
			comboBox1.Items.Add("Salata");
			comboBox1.Items.Add("Tatli");
			comboBox1.Items.Add("Icecek");

			label1.Text = "Ad�";
			label2.Text = "Cinsi";
			label3.Text = "Fiyat";
			label4.Text = "KDV Oran�";
			label5.Text = "Kalori";
		}

		private void button1_Click(object sender, EventArgs e)
		{
			// Bo� kontrol�
			if (string.IsNullOrWhiteSpace(textBoxAdi.Text) ||
				string.IsNullOrWhiteSpace(textBoxCins.Text) ||
				string.IsNullOrWhiteSpace(textBoxFiyat.Text) ||
				string.IsNullOrWhiteSpace(textBoxKdv.Text) ||
				string.IsNullOrWhiteSpace(textBoxKalori.Text))
			{
				MessageBox.Show("L�tfen t�m alanlar� doldurun.");
				return; // Metottan ��k, devam etme
			}

			// De�erleri say�sal tipe d�n��t�rme
			double fiyat, kdv, kalori;

			// TryParse, hatal� veri gelirse false d�nd�r�r ve program hata vermez
			bool fiyatOk = double.TryParse(textBoxFiyat.Text, out fiyat);
			bool kdvOk = double.TryParse(textBoxKdv.Text, out kdv);
			bool kaloriOk = double.TryParse(textBoxKalori.Text, out kalori);

			if (fiyat < 0 || kdv < 0 || kalori < 0)
			{
				MessageBox.Show("L�tfen Fiyat, KDV ve Kalori alanlar�na 0'dan b�y�k de�erler giriniz.");
				return;
			}

			// E�er birisi �evrilememi�se, kullan�c� yanl�� girdi demektir
			if (!fiyatOk || !kdvOk || !kaloriOk)
			{
				MessageBox.Show("L�tfen Fiyat, KDV ve Kalori alanlar�na say�sal de�er girin.");
				return;
			}

			// Ad ve Cins metin olarak al
			string adi = textBoxAdi.Text;
			string cins = textBoxCins.Text;

			// comboBox se�imi
			string secilenTur = comboBox1.Text;
			if (string.IsNullOrWhiteSpace(secilenTur))
			{
				MessageBox.Show("L�tfen bir yiyecek t�r� se�in.");
				return;
			}

			// switch ile alt s�n�f olu�turma
			switch (secilenTur)
			{
				case "Meyve":
					s = new Meyve(adi, cins, fiyat, kdv, kalori);
					break;
				case "Salata":
					s = new Salata(adi, cins, fiyat, kdv, kalori);
					break;
				case "Tatli":
					s = new Tatli(adi, cins, fiyat, kdv, kalori);
					break;
				case "Icecek":
					s = new Icecek(adi, cins, fiyat, kdv, kalori);
					break;
				default:
					MessageBox.Show("L�tfen bir yiyecek t�r� se�in.");
					return;
			}

			// Nesneyi men�ye ekle
			m.Ekle(s);

			// ListBox�� g�ncelle
			listBox1.Items.Clear();
			List<Yiyecek> listemiz = m.MenuYazdir();
			foreach (var item in listemiz)
			{
				listBox1.Items.Add(item.Yazdir());
			}

			// Toplam hesaplamalar
			double toplamKalori = 0;
			double toplamFiyat = 0;
			foreach (var yi in listemiz)
			{
				if (yi is Meyve meyve)
					toplamKalori += meyve.kalori;
				else if (yi is Salata salata)
					toplamKalori += salata.kalori;
				else if (yi is Tatli tatli)
					toplamKalori += tatli.kalori;
				else if (yi is Icecek icecek)
					toplamKalori += icecek.kalori;

				toplamFiyat += yi.fiyat;
			}

			// Label�lara yaz
			labelKalori.Text = $"Kalori: {toplamKalori}";
			labelTutar.Text = $"Fiyat: {toplamFiyat}";

			// Aral�k kontrol�
			if (toplamKalori <= 2000 && toplamFiyat <= 500)
			{
				MessageBox.Show("Men� kabul edildi:\n" +
					$"Toplam Kalori: {toplamKalori}\n" +
					$"Toplam Fiyat: {toplamFiyat}");
			}
			else
			{
				MessageBox.Show("Men�, belirtilen aral���n d���ndad�r.\n" +
					$"Toplam Kalori: {toplamKalori}\n" +
					$"Toplam Fiyat: {toplamFiyat}");
			}
		}

		private void buttonSil_Click_Click(object sender, EventArgs e)
		{
			// ListBox�tan se�ili index�i al�yoruz
			int seciliIndex = listBox1.SelectedIndex;

			// Se�ili bir eleman var m�?
			if (seciliIndex >= 0)
			{
				// Men� s�n�f�ndaki Sil metodunu �a��r�yoruz
				m.Sil(seciliIndex);

				// ListBox�� tazele
				listBox1.Items.Clear();
				var listemiz = m.MenuYazdir();

				foreach (var item in listemiz)
				{
					listBox1.Items.Add(item.Yazdir());
				}
			}
			else
			{
				MessageBox.Show("Listede silmek i�in bir ��e se�mediniz.");
			}
		}
	}
}
