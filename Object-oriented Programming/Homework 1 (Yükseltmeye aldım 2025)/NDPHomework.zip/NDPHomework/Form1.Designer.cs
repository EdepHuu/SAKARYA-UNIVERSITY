﻿namespace NDPHomework
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			comboBox1 = new ComboBox();
			label1 = new Label();
			label2 = new Label();
			label3 = new Label();
			label4 = new Label();
			label5 = new Label();
			textBoxAdi = new TextBox();
			textBoxCins = new TextBox();
			textBoxFiyat = new TextBox();
			textBoxKdv = new TextBox();
			textBoxKalori = new TextBox();
			button1 = new Button();
			listBox1 = new ListBox();
			labelTutar = new Label();
			labelKalori = new Label();
			buttonSil_Click = new Button();
			label6 = new Label();
			SuspendLayout();
			// 
			// comboBox1
			// 
			comboBox1.FormattingEnabled = true;
			comboBox1.Location = new Point(200, 39);
			comboBox1.Margin = new Padding(3, 2, 3, 2);
			comboBox1.Name = "comboBox1";
			comboBox1.Size = new Size(133, 23);
			comboBox1.TabIndex = 0;
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Location = new Point(106, 83);
			label1.Name = "label1";
			label1.Size = new Size(25, 15);
			label1.TabIndex = 1;
			label1.Text = "Adı";
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Location = new Point(106, 121);
			label2.Name = "label2";
			label2.Size = new Size(33, 15);
			label2.TabIndex = 2;
			label2.Text = "Cinsi";
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Location = new Point(106, 158);
			label3.Name = "label3";
			label3.Size = new Size(32, 15);
			label3.TabIndex = 3;
			label3.Text = "Fiyat";
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Location = new Point(106, 196);
			label4.Name = "label4";
			label4.Size = new Size(29, 15);
			label4.TabIndex = 4;
			label4.Text = "KDV";
			// 
			// label5
			// 
			label5.AutoSize = true;
			label5.Location = new Point(106, 233);
			label5.Name = "label5";
			label5.Size = new Size(37, 15);
			label5.TabIndex = 5;
			label5.Text = "Kalori";
			// 
			// textBoxAdi
			// 
			textBoxAdi.Location = new Point(223, 80);
			textBoxAdi.Margin = new Padding(3, 2, 3, 2);
			textBoxAdi.Name = "textBoxAdi";
			textBoxAdi.Size = new Size(110, 23);
			textBoxAdi.TabIndex = 6;
			// 
			// textBoxCins
			// 
			textBoxCins.Location = new Point(223, 117);
			textBoxCins.Margin = new Padding(3, 2, 3, 2);
			textBoxCins.Name = "textBoxCins";
			textBoxCins.Size = new Size(110, 23);
			textBoxCins.TabIndex = 7;
			// 
			// textBoxFiyat
			// 
			textBoxFiyat.Location = new Point(223, 155);
			textBoxFiyat.Margin = new Padding(3, 2, 3, 2);
			textBoxFiyat.Name = "textBoxFiyat";
			textBoxFiyat.Size = new Size(110, 23);
			textBoxFiyat.TabIndex = 8;
			// 
			// textBoxKdv
			// 
			textBoxKdv.Location = new Point(223, 193);
			textBoxKdv.Margin = new Padding(3, 2, 3, 2);
			textBoxKdv.Name = "textBoxKdv";
			textBoxKdv.Size = new Size(110, 23);
			textBoxKdv.TabIndex = 9;
			// 
			// textBoxKalori
			// 
			textBoxKalori.Location = new Point(223, 230);
			textBoxKalori.Margin = new Padding(3, 2, 3, 2);
			textBoxKalori.Name = "textBoxKalori";
			textBoxKalori.Size = new Size(110, 23);
			textBoxKalori.TabIndex = 10;
			// 
			// button1
			// 
			button1.Location = new Point(224, 274);
			button1.Margin = new Padding(3, 2, 3, 2);
			button1.Name = "button1";
			button1.Size = new Size(109, 27);
			button1.TabIndex = 11;
			button1.Text = "Ekle";
			button1.UseVisualStyleBackColor = true;
			button1.Click += button1_Click;
			// 
			// listBox1
			// 
			listBox1.FormattingEnabled = true;
			listBox1.ItemHeight = 15;
			listBox1.Location = new Point(397, 39);
			listBox1.Margin = new Padding(3, 2, 3, 2);
			listBox1.Name = "listBox1";
			listBox1.Size = new Size(537, 214);
			listBox1.TabIndex = 12;
			// 
			// labelTutar
			// 
			labelTutar.AutoSize = true;
			labelTutar.Location = new Point(397, 275);
			labelTutar.Name = "labelTutar";
			labelTutar.Size = new Size(0, 15);
			labelTutar.TabIndex = 13;
			// 
			// labelKalori
			// 
			labelKalori.AutoSize = true;
			labelKalori.Location = new Point(572, 275);
			labelKalori.Name = "labelKalori";
			labelKalori.Size = new Size(0, 15);
			labelKalori.TabIndex = 14;
			// 
			// buttonSil_Click
			// 
			buttonSil_Click.Location = new Point(107, 274);
			buttonSil_Click.Name = "buttonSil_Click";
			buttonSil_Click.Size = new Size(110, 27);
			buttonSil_Click.TabIndex = 15;
			buttonSil_Click.Text = "Sil";
			buttonSil_Click.UseVisualStyleBackColor = true;
			buttonSil_Click.Click += buttonSil_Click_Click;
			// 
			// label6
			// 
			label6.AutoSize = true;
			label6.Location = new Point(106, 42);
			label6.Name = "label6";
			label6.Size = new Size(68, 15);
			label6.TabIndex = 16;
			label6.Text = "Yiyecek Seç";
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(981, 382);
			Controls.Add(label6);
			Controls.Add(buttonSil_Click);
			Controls.Add(labelKalori);
			Controls.Add(labelTutar);
			Controls.Add(listBox1);
			Controls.Add(button1);
			Controls.Add(textBoxKalori);
			Controls.Add(textBoxKdv);
			Controls.Add(textBoxFiyat);
			Controls.Add(textBoxCins);
			Controls.Add(textBoxAdi);
			Controls.Add(label5);
			Controls.Add(label4);
			Controls.Add(label3);
			Controls.Add(label2);
			Controls.Add(label1);
			Controls.Add(comboBox1);
			Margin = new Padding(3, 2, 3, 2);
			Name = "Form1";
			Text = "Form1";
			Load += Form1_Load;
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private ComboBox comboBox1;
		private Label label1;
		private Label label2;
		private Label label3;
		private Label label4;
		private Label label5;
		private TextBox textBoxAdi;
		private TextBox textBoxCins;
		private TextBox textBoxFiyat;
		private TextBox textBoxKdv;
		private TextBox textBoxKalori;
		private Button button1;
		private ListBox listBox1;
		private Label labelTutar;
		private Label labelKalori;
		private Button buttonSil_Click;
		private Label label6;
	}
}
