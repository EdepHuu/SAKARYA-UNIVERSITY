﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NDPHomework.Models
{
	class Menu
	{
		// Yiyecek tipinde List koleksiyonu
		private List<Yiyecek> liste;

		public Menu()
		{
			liste = new List<Yiyecek>();
		}

		// Ekle metodu
		public void Ekle(Yiyecek y)
		{
			liste.Add(y);
		}

		// Sil metodu
		public void Sil(int index)
		{
			if (index >= 0 && index < liste.Count)
			{
				liste.RemoveAt(index);
			}
		}

		// menuYazdir metodu - listeyi döndürüyor
		public List<Yiyecek> MenuYazdir()
		{
			return liste;
		}
	}
}
