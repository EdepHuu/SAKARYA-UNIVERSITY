﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NDPHomework.Models
{
	class Salata : Yiyecek
	{
		public double kalori;

		// Varsayılan kurucu
		public Salata() : base()
		{
			kalori = 0;
		}

		// Parametreli kurucu
		public Salata(string a, string c, double f, double kdv, double kal)
			: base(a, c, f, kdv)
		{
			kalori = kal;
		}

		public override string Yazdir()
		{
			string data = String.Format("{0,-10} {1,-10} {2,-10} {3,-5} {4,-5} {5,-10}",
		adi, cins, fiyat, kdvOrani, kalori, "Salata");
			return data;
		}
	}
}
