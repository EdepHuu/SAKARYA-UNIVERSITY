/**
*
* @author Metehan DÜNDAR	metehan.dundar@ogr.sakarya.edu.tr
* @since 10.04.2023
* <p>
* 2. Öğretim C Grubu
* </p>
*/


package odev;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class odev {
	
	//regex kodları
	private static final Pattern CLASS_PATTERN = Pattern.compile("class\\s+(\\w+)");  
	//Sınıfların adlarını eşleştirmeye yarar.
	private static final Pattern FUNCTION_PATTERN = Pattern.compile("(public|protected|private|static|\\s) +([\\w\\<\\>\\[\\]]+\\s+)?(\\w+) *\\([^{]*\\{"); 
	// Fonksiyon metod tanımlarını eşleştirmeye yarar.
    private static final Pattern SINGLE_LINE_COMMENT_PATTERN = Pattern.compile("//.*");  
    // Tek satırlık yorumları tespit eder.
    private static final Pattern MULTI_LINE_COMMENT_PATTERN = Pattern.compile("/\\*[^*]*\\*+(?:[^/*][^*]*\\*+)*/"); 
    // Çok satırlı yorumları tespit eder.
    private static final Pattern JAVADOC_COMMENT_PATTERN = Pattern.compile("/\\*\\*(.|\\R)*?\\*/"); 
    // Javadoc yorumları tespit eder.
     
	
	public static void main(String[] args) {
		if (args.length == 0) {
	        System.out.println("Lütfen bir Java dosyasının yolunu belirtin.");
	        return;
	    }
		// Burada .java kaynak dosyasını okuyoruz ve bunu saklamak için string değişkeni tanımlıyoruz.
	    String javaFilePath = args[0];
	    String content;
	    try {
	        content = new String(Files.readAllBytes(Paths.get(javaFilePath)));
	    } catch (IOException e) {
	        System.err.println("Dosya okunamadi: " + javaFilePath);
	        return;
	    }
	    // .java Dosyası içerisindeki sınıfı arayıp buluyoruz
	    Matcher classMatcher = CLASS_PATTERN.matcher(content);
	    String className = "";
	    if (classMatcher.find()) {
	        className = classMatcher.group(1);
	    }
	    // Okuduğumuz .java dosyasındaki sınıf ismini yazdırıyoruz.
	    System.out.println("Sinif: " + className);
	    // txt'ye yorumları yazdırmadan önce txt dosyalarının içini siliyoruz.
	    clearFile("teksatir.txt");
	    clearFile("coksatir.txt");
	    clearFile("javadoc.txt");
	    // java dosyası içerisindeki fonksiyonları arayıp analyzefunction fonksiyonuna yollayıp çağırıyoruz.
	    Matcher functionMatcher = FUNCTION_PATTERN.matcher(content);
	    while (functionMatcher.find()) {
	        String functionName = functionMatcher.group(3);
	        analyzeFunction(content, functionName, functionMatcher.start());
	    }
	    
	}
	
	//Dosyaya yazdırıma işlemi burda yapılıyor
	private static void writeFile(String filename, String functionName, List<String> comments) {
	    try { //txt dosyaları yoksa olusuturuyoruz.
	        File file = new File(filename);
	        if (!file.exists()) {
	            file.createNewFile();
	        }
	        // Dosyalara yazmak için nesne oluşturma
	        FileWriter fileWriter = new FileWriter(file, true);
	        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
	        /* Bu iki nesne, belirtilen dosyaya veri yazarken kullanılır. İlk olarak FileWriter ile dosyaya yazma 
	        işlemi başlatılır, ardından BufferedWriter ile bu işlem daha verimli hale getirilir. */
	        if (!comments.isEmpty()) {
	            bufferedWriter.write("Fonksiyon: " + functionName + "\n");
	            for (String comment : comments) {
	                bufferedWriter.write(comment + "\n");
	            }
	            bufferedWriter.write("-----------------------------------------\n");
	        }

	        bufferedWriter.close();
	        fileWriter.close();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}

	
	private static void clearFile(String filename) {
	    try {	// Dosya içeriklerini temizliyoruz.
	        File file = new File(filename);
	        if (file.exists()) {
	            FileWriter fileCleaner = new FileWriter(file, false);
	            fileCleaner.write(""); // dosya içeriğini silmiş oluyoruz.
	            fileCleaner.close();
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}

	
	private static void analyzeFunction(String content, String functionName, int functionStart) {
		
	    int nextFunctionStart = content.indexOf('{', functionStart) + 1;
	    //Fonksiyonun açılış konumunu bulur ve bu konumun bir sonraki karakterine işaret eden bir indeks değeri oluşturur.
	    int bracketCount = 1;
	    int functionEnd; // Fonksiyonun kapanışı.

	    for (functionEnd = nextFunctionStart; functionEnd < content.length(); functionEnd++) {
	        if (content.charAt(functionEnd) == '{') {
	            bracketCount++;
	        } else if (content.charAt(functionEnd) == '}') {
	            bracketCount--;
	            if (bracketCount == 0) { // burası fonksiyonun kapanışını temsil eder "}". Döngü sonlanır.
	                break;
	            }
	        }
	    }

	    String functionContent = content.substring(functionStart, functionEnd + 1);
	    // Fonksiyonun başlangıç ve bitiş konumları arasındaki içeriği alır ve functionContent değişkenine atar.
	    String contentBeforeFunction = content.substring(0, functionStart);
	    // Burası önemli javadoc yorumları için bu kısımda fonksiyondan önceki içeriği alıyoruz.
	    
	    System.out.println("\nFonksiyon: " + functionName);
	    System.out.println("Tek Satir Yorum Sayisi: " + countMatches(functionContent, SINGLE_LINE_COMMENT_PATTERN));
	    System.out.println("Cok Satirli Yorum Sayisi: " + (countMatches(functionContent, MULTI_LINE_COMMENT_PATTERN) - countMatches(functionContent, JAVADOC_COMMENT_PATTERN)));
	    System.out.println("Javadoc Yorum Sayisi: " + countJavadocComments(functionContent, contentBeforeFunction));
	    System.out.print("--------------------------------------------");
	    // Çıktılar ekranda gösteriliyor ^^^^
	    List<String> singleLineComments = getMatches(functionContent, SINGLE_LINE_COMMENT_PATTERN);
	    List<String> multiLineComments = getMatches(functionContent, MULTI_LINE_COMMENT_PATTERN);
	    multiLineComments.removeAll(getMatches(functionContent, JAVADOC_COMMENT_PATTERN));
	    List<String> javadocComments = new ArrayList<>();

	    int javadocCount = countJavadocComments(functionContent, contentBeforeFunction);
	    //fonksiyondan önceki javaoc yorum sayıları için.
	    if (javadocCount > 0) {
	        javadocComments = getMatches(contentBeforeFunction, JAVADOC_COMMENT_PATTERN);
	        javadocComments = javadocComments.subList(javadocComments.size() - javadocCount, javadocComments.size());
	    }
	    // writefile fonksiyonu çağırılır ve txt dosyalarına yorumlar istenilen formatta ayrı ayrı yazılır.
	    writeFile("teksatir.txt", functionName, singleLineComments);
	    writeFile("coksatir.txt", functionName, multiLineComments);
	    writeFile("javadoc.txt", functionName, javadocComments);
	}



	// regex ifadelerin eşleşmelerini buluyoruz*
	private static List<String> getMatches(String content, Pattern pattern) {
	    Matcher matcher = pattern.matcher(content);
	    List<String> matches = new ArrayList<>();
	    // eşleşen metinleri saklamak için bir arraylist oluşturuyoruz.
	    while (matcher.find()) {
	        matches.add(matcher.group());
	    }
	    
	    return matches;
	}
	
	/* Bu fonksiyonla bir Java dosyasındaki belirli bir fonksiyonun içinde ve hemen öncesinde yer alan 
	 Javadoc yorumlarını sayıyoruz. */
	private static int countJavadocComments(String functionContent, String contentBeforeFunction) {
	    int lastJavadocCommentEnd = contentBeforeFunction.lastIndexOf("*/");
	
	    if (lastJavadocCommentEnd != -1) {
	        String contentAfterLastJavadocComment = contentBeforeFunction.substring(lastJavadocCommentEnd);
	        if (!FUNCTION_PATTERN.matcher(contentAfterLastJavadocComment).find()) {
	            String javadocBeforeFunction = contentBeforeFunction.substring(0, lastJavadocCommentEnd + 2);
	            int functionJavadocCommentCount = countMatches(javadocBeforeFunction, JAVADOC_COMMENT_PATTERN);
	
	            if (functionJavadocCommentCount > 0) {
	                int nextFunctionStart = contentAfterLastJavadocComment.indexOf("{");
	                if (nextFunctionStart != -1) {
	                    String betweenComments = contentAfterLastJavadocComment.substring(0, nextFunctionStart).trim();
	
	                    if (!FUNCTION_PATTERN.matcher(betweenComments).find() && !betweenComments.isEmpty()) {
	                        return 1;
	                    }
	                } else {
	                    return 1;
	                }
	            }
	        }
	    }
	
	    // Add Javadoc comments inside functions
	    int javadocInsideFunctionCount = 0;
	    Matcher javadocInsideFunctionMatcher = JAVADOC_COMMENT_PATTERN.matcher(functionContent);
	    while (javadocInsideFunctionMatcher.find()) {
	        if (FUNCTION_PATTERN.matcher(functionContent.substring(javadocInsideFunctionMatcher.start())).find()) {
	            javadocInsideFunctionCount++;
	        }
	    }
	
	    return javadocInsideFunctionCount;
	}
	/* Bu fonksiyonla ise bir metin içinde belirli bir düzenli ifadeye (regex) 
	uyan tüm metin parçalarının sayısını elde etmek için kullandık. */
	private static int countMatches(String content, Pattern pattern) {
	    Matcher matcher = pattern.matcher(content);
	    int count = 0;
	    while (matcher.find()) {
	        count++;
	    }
	    return count;
	}
}
