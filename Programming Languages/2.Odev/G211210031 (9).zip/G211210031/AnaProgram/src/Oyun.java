/**
*
* @author Metehan DÜNDAR	metehan.dundar@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* 2. Öğretim C Grubu
* </p>
*/

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

//Oyun sınıfı, Koloni sınıfı tarafından oluşturulan koloniler arasında bir oyun oynamak için tasarlanmıştır.
public class Oyun 
{
	// Koloniler listesi, oyunun oynanacağı kolonileri içerir.
    List<Koloni> koloniler;

    // Oyun başlangıcındaki orijinal koloniler listesi.
    List<Koloni> initialKoloniler;

    // Oyun sınıfının yapıcı metodu, bir Koloni listesi alır ve bu listeyi sınıfın koloniler alanına atar.
    public Oyun(List<Koloni> koloniler) {
        this.koloniler = koloniler;

        // Oyunun başlangıcındaki koloniler listesinin bir kopyasını oluşturuyoruz.
        this.initialKoloniler = new ArrayList<>(koloniler);  
    }

    // Oyunun başladığı yer. Oyun döngüsü bu metot içinde yer alır.
    public void play() {
        // İki koloni arasındaki savaş sonuçlarını tutan 2 boyutlu bir dizi oluşturulur.
        int[][] savasSonucu = new int[koloniler.size()][koloniler.size()];
        int turSayisi = 0;

        // Oyun devam ederken, her koloni sırayla diğer tüm kolonilerle savaşır.
        while (koloniler.size() > 1) {
            // Her turun başında, savasSonucu dizisini sıfırlarız.
            for (int i = 0; i < koloniler.size(); i++) {
                Arrays.fill(savasSonucu[i], 0);
            }

            // Her turda her bir koloninin popülasyonunu ve yemek stoğunu güncelliyoruz.
            for (Koloni k : koloniler) {
                k.population += k.population * 0.2;  // Popülasyon %20 oranında artar
                k.foodStock -= k.population * 2;    // Yemek stoğu (GüncelPopülasyon x 2) oranında azalır
                k.foodStock += k.uretim.uret();     // Yemek stoğuna koloninin üretim değeri eklenir
            }

            // Her koloni sırayla diğer tüm kolonilerle savaşır.
            for (int i = 0; i < koloniler.size(); i++) {
                Koloni a = koloniler.get(i);
                for (int j = i+1; j < koloniler.size(); j++) {
                    Koloni b = koloniler.get(j);
                    a.battle(b, savasSonucu, i, j);  // Koloni a, koloni b ile savaşır
                }
            }

            // Sonraki turda aktif olacak kolonileri belirliyoruz.
            List<Koloni> yeniKoloniler = new ArrayList<>();
            for (Koloni k : koloniler) {
                if (k.population > 0) {  // Eğer koloninin popülasyonu 0'dan büyükse, yeni turda da var olacaktır.
                    yeniKoloniler.add(k);
                }
            }
            // Yeni koloniler listesini ana koloniler listesiyle değiştiriyoruz.
            koloniler = yeniKoloniler;

            // Her turun sonunda, o anki durumu gösteren bir tablo basıyoruz.
            System.out.println("---------------------------------------------------------------------------------------------------------");
            System.out.println("Tur Sayisi:" + ++turSayisi);
            System.out.format("%-15s %-15s %-15s %-15s %-15s%n", "Koloni", "Populasyon", "Yemek Stogu", "Kazanma", "Kaybetme");
            
            for (Koloni k : initialKoloniler) {
                if (koloniler.contains(k)) {
                    System.out.format("%-15s %-15s %-15s %-15s %-15s%n", k.symbol, k.population, k.foodStock, k.victories, k.losses);
                } else {
                    System.out.format("%-15s %-15s %-15s %-15s %-15s%n", k.symbol, "--", "--", "--", "--");
                }
            }
            System.out.println("---------------------------------------------------------------------------------------------------------");
            System.out.println();

            // Her tur arasında 1.5 saniye bekliyoruz.
            try {
                Thread.sleep(1500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            
            // Her turun sonunda ekranı temizliyoruz.
            clearScreen();
        }
    }

    // Bu metot, işletim sistemine bağlı olarak ekranı temizler.
    public void clearScreen() 
    {
        // Sistem özelliği "os.name" kullanılarak işletim sistemi adı alınır.
        String os = System.getProperty("os.name").toLowerCase();

        try {
            if (os.contains("win")) {  // İşletim sistemi Windows ise...
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();  // "cls" komutu kullanılarak ekran temizlenir.
            } else if (os.contains("nix") || os.contains("nux") || os.contains("mac")) {  // İşletim sistemi Unix tabanlı ise (Linux, MacOS, vb.)...
                System.out.print("\033[H\033[2J");  // Ekranı temizlemek için escape dizisi kullanılır.
                System.out.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}