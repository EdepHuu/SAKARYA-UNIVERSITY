/**
*
* @author Metehan DÜNDAR	metehan.dundar@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* 2. Öğretim C Grubu
* </p>
*/

import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class AnaProgram 
{
	
	public static void main(String[] args) 
	{		
		// Kullanıcıdan girdi almak için bir Scanner nesnesi oluşturulur.
        Scanner scanner = new Scanner(System.in);
        
        // Kullanıcıdan koloni populasyonlarını girmesi istenir.
        System.out.println("Koloni populasyonlarini giriniz: ");
        
        // Kullanıcının girdisi boşluklara göre ayrıştırılır ve bir diziye atanır.
        String[] inputs = scanner.nextLine().split(" ");
        
        // Kolonileri tutmak için bir liste oluşturulur.
        List<Koloni> koloniler = new ArrayList<>();
        
        // Random nesnesi oluşturulur. Bu nesne, rastgele koloni sembolü, taktik ve üretim tipi oluşturmak için kullanılır.
        Random random = new Random();
        
        // Kullanıcının girdiği her popülasyon için...
        for(String input : inputs) {
            // ...popülasyon sayısını alırız.
            int population = Integer.parseInt(input);
            
            // Rastgele bir sembol (a-z arasında bir karakter) oluşturulur.
            String symbol = String.valueOf((char) (random.nextInt(26) + 'a'));
            
            // Rastgele bir taktik (AgresifTaktik veya SavunmaTaktik) seçilir.
            Taktik taktik = random.nextBoolean() ? new AgresifTaktik() : new SavunmaTaktik();
            
            // Rastgele bir üretim tipi (VerimliUretim veya NormalUretim) seçilir.
            Uretim uretim = random.nextBoolean() ? new VerimliUretim() : new NormalUretim();
            
            // Yeni bir koloni oluşturulur ve bu koloni listeye eklenir.
            koloniler.add(new Koloni(symbol, population, taktik, uretim));
        }

        // Oyun nesnesi oluşturulur ve koloniler ile başlatılır.
        Oyun oyun = new Oyun(koloniler);
        
        // Oyun başlatılır.
        oyun.play();
    }
}