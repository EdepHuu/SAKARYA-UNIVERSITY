/**
*
* @author Metehan DÜNDAR	metehan.dundar@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* 2. Öğretim C Grubu
* </p>
*/

public interface Taktik {
	// Bu arayüz bir metot içerir. Bu metot, implementasyonunu sağlayan sınıflar tarafından ayrıntılı bir şekilde tanımlanır.
    // savas() metodu, taktiğin savaşta ne kadar güçlü olduğunu belirler ve bu değeri döndürür.
    int savas();
}