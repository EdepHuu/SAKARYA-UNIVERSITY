/**
*
* @author Metehan DÜNDAR	metehan.dundar@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* 2. Öğretim C Grubu
* </p>
*/

import java.util.Random;
//NormalUretim sınıfı, Uretim arayüzünü implemente eder. Bu, NormalUretim sınıfının Uretim arayüzünde tanımlanan 
//tüm metodları kendi içerisinde tanımlaması gerektiği anlamına gelir.
public class NormalUretim implements Uretim{
	// Uretim arayüzünde tanımlanan uret() metodu, NormalUretim sınıfı için uygulanır. 
    // Bu metodun dönüş değeri, normal üretimin sonucunu temsil eder.
    @Override
    public int uret(){
        // Yeni bir Random nesnesi oluşturulur. nextInt(5) + 1 metodu, 1 ile 5 arasında rastgele bir sayı döndürür.
        // Bu sayı, normal üretimin sonucunu temsil eder.
        return new Random().nextInt(5) + 1;
    }
}