/**
*
* @author Metehan DÜNDAR	metehan.dundar@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* 2. Öğretim C Grubu
* </p>
*/

import java.util.Random;
//Taktik interface'ini uygulayan AgresifTaktik adında bir sınıf oluşturuyoruz.
public class AgresifTaktik implements Taktik{
	// Taktik interface'inde tanımlanan savas() metodunu override ediyoruz (yeniden tanımlıyoruz)
    @Override
    public int savas() {
        // Rastgele bir sayı üretmek için Random sınıfından bir nesne oluşturuyoruz.
        // nextInt(1001) metodu, 0 ile 1000 arasında rastgele bir tam sayı döndürür.
        return new Random().nextInt(1001);
    }
}