/**
*
* @author Metehan DÜNDAR	metehan.dundar@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* 2. Öğretim C Grubu
* </p>
*/

// Uretim, bir interface (arayüz) olarak tanımlanmıştır. 
// Interface'ler, belirli bir işlevi yerine getirmek için gereken metotları tanımlayan bir tür şablondur. 
// Bu durumda, Uretim interface'i, uret() isimli bir metodu tanımlamaktadır.
public interface Uretim {
	// uret() metodu, geriye bir integer (tam sayı) döndürmektedir.
    // Bu metot, Uretim interface'ini implemente (uygulayan) eden tüm sınıflar tarafından tanımlanmalıdır.
    int uret();
}