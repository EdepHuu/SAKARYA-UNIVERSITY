/**
*
* @author Metehan DÜNDAR	metehan.dundar@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* 2. Öğretim C Grubu
* </p>
*/

import java.util.Random;
//Uretim interface'ini uygulayan VerimliUretim adında bir sınıf oluşturuyoruz.
public class VerimliUretim implements Uretim{
	// Uretim interface'inde tanımlanan uret() metodunu override ediyoruz (yeniden tanımlıyoruz)
    @Override
    public int uret() {
        // Rastgele bir sayı üretmek için Random sınıfından bir nesne oluşturuyoruz.
        // nextInt(10) metodu, 0 ile 9 arasında rastgele bir tam sayı döndürür.
        // Sonuç olarak, bu metot 1 ile 10 arasında rastgele bir tam sayı döndürür.
        return new Random().nextInt(10) + 1;
    }
}