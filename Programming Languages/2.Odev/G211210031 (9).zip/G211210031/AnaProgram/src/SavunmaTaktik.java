/**
*
* @author Metehan DÜNDAR	metehan.dundar@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* 2. Öğretim C Grubu
* </p>
*/

import java.util.Random;
//SavunmaTaktik sınıfı, Taktik arayüzünü implemente eder. Yani, Taktik arayüzünde tanımlanan
//tüm metodları SavunmaTaktik sınıfı kendi içerisinde tanımlamak zorundadır.
public class SavunmaTaktik implements Taktik{
	// savas() metodu, SavunmaTaktik sınıfı için uygulanır. Bu metodun dönüş değeri, savunma taktiğinin
    // savaşta ne kadar güçlü olduğunu belirler.
    @Override
    public int savas() {
        // Yeni bir Random nesnesi oluşturulur. nextInt(501) metodu, 0 dahil 501 hariç rastgele bir sayı döndürür.
        // Bu sayı, savunma taktiğinin savaştaki gücünü temsil eder.
        return new Random().nextInt(501);
    }
}
