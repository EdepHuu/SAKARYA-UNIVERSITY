/**
*
* @author Metehan DÜNDAR	metehan.dundar@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* 2. Öğretim C Grubu
* </p>
*/

// Koloni sınıfı, bir koloniyi ve onun çeşitli özelliklerini temsil eder.
public class Koloni {
	// Koloninin simgesi veya adı.
    String symbol;
    
    // Koloninin mevcut popülasyonu.
    int population;
    
    // Koloninin mevcut yemek stoğu.
    int foodStock;
    
    // Koloninin kazandığı savaş sayısı.
    int victories;
    
    // Koloninin kaybettiği savaş sayısı.
    int losses;
    
    // Koloninin savaş taktiği.
    Taktik taktik;
    
    // Koloninin üretim yeteneği.
    Uretim uretim;

    // Koloni sınıfının yapıcı metodu, bir simge, popülasyon, taktik ve üretim bilgisi alır ve bu bilgileri koloninin özelliklerine atar.
    public Koloni(String symbol, int population, Taktik taktik, Uretim uretim) {
        this.symbol = symbol;
        this.population = population;
        this.foodStock = population * population;  // Başlangıçta, yemek stoğu popülasyonun karesi olarak hesaplanır.
        this.taktik = taktik;
        this.uretim = uretim;
        this.victories = 0;
        this.losses = 0;
    }

    // Bu metod, her turun sonunda koloninin popülasyon ve yemek stoğunu günceller.
    void endTurn() {
        this.population += this.population * 0.2;  // Popülasyon %20 oranında artar.
        this.foodStock -= this.population * 2;  // Yemek stoğu (GüncelPopülasyon x 2) oranında azalır.
        this.foodStock += this.uretim.uret();  // Yemek stoğuna koloninin üretim değeri eklenir.
        this.foodStock = Math.max(0, this.foodStock); // Yemek stoğu sıfırdan küçük olamaz.
    }

    // Bu metod, bu koloninin bir diğer koloniyle savaşmasını temsil eder.
    void battle(Koloni other, int[][] savasSonucu, int i, int j) {
        // Her iki koloninin savaş taktikleri ile belirlenen güçleri hesaplanır.
        int myForce = this.taktik.savas();
        int otherForce = other.taktik.savas();

        // Bu koloninin gücü diğer koloninin gücünden küçükse, ya da güçler eşitse ve bu koloninin popülasyonu diğer koloniden düşükse...
        if(myForce < otherForce || (myForce == otherForce && this.population < other.population)) {
            // ...bu koloni kaybeder ve popülasyonu ve yemek stoğu azalır.
            double rate = (double) (otherForce - myForce) / 1000;
            this.population -= this.population * rate;
            this.foodStock -= this.foodStock * rate;
            other.foodStock += this.foodStock * rate;
            this.population = Math.max(0, this.population); // Popülasyon sıfırdan küçük olamaz.
            this.losses += 1;  // Bu koloninin kayıp sayısı artar.
            other.victories += 1;  // Diğer koloninin zafer sayısı artar.
            savasSonucu[j][i] = 1;
        } else {
            // Aksi takdirde, bu koloni kazanır ve diğer koloninin popülasyonu ve yemek stoğu azalır.
            double rate = (double) (myForce - otherForce) / 1000;
            other.population -= other.population * rate;
            other.foodStock -= other.foodStock * rate;
            this.foodStock += other.foodStock * rate;
            other.population = Math.max(0, other.population); // Popülasyon sıfırdan küçük olamaz.
            other.losses += 1;  // Diğer koloninin kayıp sayısı artar.
            this.victories += 1;  // Bu koloninin zafer sayısı artar.
            savasSonucu[i][j] = 1;
        }
    }
}